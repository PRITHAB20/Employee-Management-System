
CREATE DATABASE employee_management;
USE employee_management;
CREATE TABLE users(id INT PRIMARY KEY AUTO_INCREMENT,username VARCHAR(50),password VARCHAR(100),role VARCHAR(20));
CREATE TABLE employees(emp_id INT PRIMARY KEY AUTO_INCREMENT,name VARCHAR(100),department VARCHAR(100),salary DOUBLE,email VARCHAR(100));
INSERT INTO users(username,password,role) VALUES('admin','admin123','admin');
